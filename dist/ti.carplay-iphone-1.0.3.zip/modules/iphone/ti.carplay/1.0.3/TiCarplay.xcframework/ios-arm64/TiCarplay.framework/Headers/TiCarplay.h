//
//  TiCarplay.h
//  titanium-carplay
//
//  Created by Your Name
//  Copyright (c) 2023 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiCarplay.
FOUNDATION_EXPORT double TiCarplayVersionNumber;

//! Project version string for TiCarplay.
FOUNDATION_EXPORT const unsigned char TiCarplayVersionString[];

#import <TiCarplay/TiCarplayModuleAssets.h>
